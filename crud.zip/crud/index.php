<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Create your Account</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<script src="js/skel.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-wide.css" />
			<link rel="stylesheet" href="css/style-noscript.css" />
		</noscript>

  		<!-- Favicons -->
  		<link href="../img/favicon.png" rel="icon">
  		<link href="../img/apple-touch-icon.png" rel="apple-touch-icon">
		
  		<!--external css-->
  		<link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  		<link rel="stylesheet" type="text/css" href="../css/zabuto_calendar.css">
  		<link rel="stylesheet" type="text/css" href="../lib/gritter/css/jquery.gritter.css" />
	</head>
	<body class="loading">
		<div id="wrapper">
			<div id="bg"></div>
			<div id="overlay"></div>
			<div id="main">

				<!-- Header -->
					<header id="header">
						<h1>Sign Up <i class="fa fa-sign-in" aria-hidden="true"></i></h1>
					</header>

					<section class="loginform">
						<form action="process.php" method="post">
						  <div class="namem">
                            <label class="name1">Name : </label>
    						<input type="text" placeholder="Enter Name" id="name" name="name" required>
    					  </div><br>

    					  <div class="emailm">
                            <label class="email1">Email Id : </label>
    						<input type="email" placeholder="Enter Email" id="email" name="email" required>
    					  </div><br>

    					  <div class="passwordm">
   						  	<label class="password1">Password : </label>
    						<input type="password" placeholder="Enter Password" id="password" name="password" required>
    					  </div><br>

    					  <div class="cpasswordm">
   						  	<label class="cpassword1">Confirm Password : </label>
    						<input type="password" placeholder="Re-type Password" id="cpassword" name="cpassword" required>
    					  </div><br>

    					  <div class="mobilem">
   						  	<label class="mobile1">Mobile No. : </label>
    						<input type="text" placeholder="Enter mobile no." id="mobile" name="mobile" required>
    					  </div><br>

    						<input type="submit" onclick="return validate()" class="loginbtn" name="submit" value="Sign Up">
    					</form>

    					<div class="socialbtn">
            			<p class="signupscl">Or you can sign in via your social network</p>
            			<form action="#">
            			<button class="btnfb" type="submit"><i class="fa fa-facebook"></i> Facebook</button>
            			<button class="btntw" type="submit"><i class="fa fa-twitter"></i> Twitter</button>
            			</form>
          				</div>

    				    <p class="signupln">Already have an account? <a href="signin/index.php"> &nbsp;&nbsp;Sign In&nbsp;&nbsp; </a></p>
					</section>

				<!-- Footer -->
					<footer id="footer">
						<span class="copyrit"></span>
					</footer>
				
			</div>
		</div>
	</body>
</html>

<script>
function validate(){
		var temp = 0;

		var	password = $('#password').val();
		var conpass  = $('#cpassword').val();

		if(conpass != password){
			alert('Password & Confirm Password does not matched.');
			temp++;
		}

		if(!$('#mobile').val().match('[0-9]{10}'))  {
            alert("Please put 10 digit mobile number");
            temp++;
        }

		if(temp==0){
			return true;
		}else{
			return false;
		}
}
</script>
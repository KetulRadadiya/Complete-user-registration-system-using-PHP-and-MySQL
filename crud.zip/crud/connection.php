<?php
 
  $conn = mysqli_connect("localhost","root","","demo1");
  if(!$conn){
  	echo 'Error to connect';
  }

?>
<?php
	require'../connection.php';

session_start();

$email = $_POST['email'];
$pass  = $_POST['password'];

$sql = "SELECT * FROM `crud` WHERE `Email` = '$email'";
$run = mysqli_query($conn,$sql);

$raw = mysqli_fetch_assoc($run);
$_SESSION['Name'] = $raw['Name'];

$count = mysqli_num_rows($run);

$db_pass = $raw['Password'];

$decode = password_verify($pass, $db_pass);

if(isset($_POST['submit'])){
	if ($count) {
		    if($decode){
				header('location:../Platform/index.php');
			}else{?>
				<script>
				alert("Incorrect Password, Please login again.");
    		    window.location.href = "index.php";	
    			</script>
				<?php
			}
	}
	else{
		?>
		<script>	
			alert("Incorrect Email, Please login again.");
    		window.location.href = "index.php";
		</script>
		<?php
	}
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Sign in to veronica</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<script src="js/skel.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-wide.css" />
			<link rel="stylesheet" href="css/style-noscript.css" />
		</noscript>
  		<!-- Favicons -->
  		<link href="../img/favicon.png" rel="icon">
  		<link href="../img/apple-touch-icon.png" rel="apple-touch-icon">
		
  		<!--external css-->
  		<link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  		<link rel="stylesheet" type="text/css" href="../css/zabuto_calendar.css">
  		<link rel="stylesheet" type="text/css" href="../lib/gritter/css/jquery.gritter.css" />
	</head>
	<body class="loading">
		<div id="wrapper">
			<div id="bg"></div>
			<div id="overlay"></div>
			<div id="main">

				<!-- Header -->
					<header id="header">
						<h1>LOG IN <i class="fa fa-sign-in" aria-hidden="true"></i></h1>
					</header>

					<section class="loginform">
						<form action="loginprocess.php" method="post">
						  <div class="emailm">
                            <label class="email1">Email Id : </label>
    						<input type="email" placeholder="Email Id" id="email" name="email" required>
    					  </div><br>

    					  <div class="passwordm">
   						  	<label class="password1">Password : </label>
    						<input type="password" placeholder="Password" id="password" name="password" required>
    					  </div><br>

    						<input type="submit" class="loginbtn" name="submit" value="Login">
    					</form>

    					<div class="socialbtn">
            			<p class="signupscl">Or you can sign in via your social network</p>
            			<form action="#">
            			<button class="btnfb" type="submit"><i class="fa fa-facebook"></i> Facebook</button>
            			<button class="btntw" type="submit"><i class="fa fa-twitter"></i> Twitter</button>
            			</form>
          				</div>

    				    <p class="signupln">Don't have an account yet ? <a href="../index.php"> &nbsp;&nbsp;Create an account&nbsp;&nbsp; </a></p>
					</section>

				<!-- Footer -->
					<footer id="footer">
						<span class="copyrit"></span>
					</footer>
				
			</div>
		</div>
	</body>
</html>
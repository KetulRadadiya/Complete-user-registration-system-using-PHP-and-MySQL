<?php
  require'connection.php';

$name = $_POST['name'];
$email = $_POST['email'];
$pass  = $_POST['password'];
$crptpass = password_hash($pass, PASSWORD_BCRYPT);//blowFish password encryption
$mob  = $_POST['mobile'];


$sql = "SELECT * FROM `crud` WHERE Email = '$email'";
$res = mysqli_query($conn,$sql);

if(isset($_POST['submit'])){
	if(mysqli_num_rows($res) > 0){
		?>
	  <script>	alert("This Email Id already taken, Please signup using another Email.")
    			window.location.href = "index.php";
	  </script>
	<?php
	}else{
		$sql = "INSERT INTO `crud`(`Name`, `Email`, `Pasword`, `Mobile`) VALUES ('$name','$email','$crptpass','$mob')";

			$run = mysqli_query($conn,$sql);
			if($run){
				header("Location:signin/index.php");
			}
			else{
				die('Connection to database Failed :(');
			}
	}
}
?>


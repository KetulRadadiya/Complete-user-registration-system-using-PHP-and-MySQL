<?php
	session_start();
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Veronica</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/jquery.scrollgress.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-wide.css" />
		</noscript>
	</head>
	<body class="landing">

		<!-- Header -->
			<header id="header" class="alt">
				<h1><a href="index.php">Veronica</a> by KR</h1>
				<nav id="nav">
					<ul>
						<li><a href="index.php">Home</a></li>
						<li>
							<a href="" class="icon fa-angle-down">Explore</a>
							<ul>
								<li><a href="generic.php">Overview</a></li>
								<li><a href="contact.php">Contact</a></li>
							</ul>
						</li>
						<?php if(array_key_exists('Name',$_SESSION) && !empty($_SESSION['Name'])){
						        echo "<li><a href='logout.php' class='button'>Sign Out</a></li>";
						    }else{
						    	echo "<li><a href='../signin/index.php' class='button'>Sign In</a></li>";
						    }?>
					</ul>
				</nav>
			</header>

		<!-- Banner -->
			<section id="banner">
				<img src="">
				<h2>veronica</h2>
				<p>Welcomes you, <span style="font-weight:900"><?php if(array_key_exists('Name',$_SESSION) && !empty($_SESSION['Name'])){
						echo $_SESSION['Name'];
					}else{
						echo 'Guest';
					}?></span></p>
				<?php if(!empty($_SESSION['Name'])){
					echo  "<ul class='actions'>
										  <li><a href='logout.php' class='button special'>Sign Out</a></li>
										  <li><a href='generic.php' class='button'>Learn More</a></li></ul>";
				} else {
					echo "<ul class='actions'>
										  <li><a href='../signin/index.php' class='button special'>Sign In</a></li>
										  <li><a href='generic.php' class='button'>Learn More</a></li></ul>";
				} ?>
			</section>

		<!-- Main -->
			<section id="main" class="container">
		
				<section class="box special">
					<header class="major">
						<h2>If you truly love nature,
						<br />
						you will find beauty everywhere</h2>
						<p>Everything in nature invites us constantly to be what we are.<br />
						In all things of nature there is something of the marvelous.</p>
					</header>
					<span class="image featured"><img src="https://source.unsplash.com/1200x400/?nature,water
" alt="" /></span>
				</section>
						
				<section class="box special features">
					<div class="features-row">
						<section>
							<span class="icon major fa-bolt accent2"></span>
							<h3>Lite & Fast</h3>
							<p>I love performing outside because it's as if the heavens are open and the elements become part of the stage show as well - you know, the wind and the rain and the thunder. It's almost as if there's a sense of invocation in performance.</p>
						</section>
						<section>
							<span class="icon major fa-area-chart accent3"></span>
							<h3>Graphic & Designs</h3>
							<p>Good design’s not about what medium you’re working in. It’s about thinking hard about what you want to do and what you have to work with before you start.</p>
						</section>
					</div>
					<div class="features-row">
						<section>
							<span class="icon major fa-cloud accent4"></span>
							<h3>Cloud Server</h3>
							<p>I don’t need a hard disk in my computer if I can get to the server faster… carrying around these non-connected computers is byzantine by comparison.</p>
						</section>
						<section>
							<span class="icon major fa-lock accent5"></span>
							<h3>Security</h3>
							<p>Arguing that you don’t care about the right to privacy because you have nothing to hide is no different than saying you don’t care about free speech because you have nothing to say.</p>
						</section>
					</div>
				</section>
				<form method="post" action="#">
					<div class="row uniform 50%">
						<div class="9u 12u(3)">
							<input type="text" name="query" id="query" value="" placeholder="Query" />
						</div>
						<div class="3u 12u(3)">
							<input type="submit" value="Search" class="fit" />
						</div>
					</div>
				</form>
				<div class="row">
					<div class="6u 12u(2)">

						<section class="box special">
							<span class="image featured"><img src="https://source.unsplash.com/576x256/?webDevelopment
" alt="" /></span>
							<h3>Web Development</h3>
							<p>Integer volutpat ante et accumsan commophasellus sed aliquam feugiat lorem aliquet ut enim rutrum phasellus iaculis accumsan dolore magna aliquam veroeros.</p>
							<ul class="actions">
								<li><a href="generic.php" class="button alt">Learn More</a></li>
							</ul>
						</section>
						
					</div>
					<div class="6u 12u(2)">

						<section class="box special">
							<span class="image featured"><img src="https://source.unsplash.com/576x256/?server" alt="" /></span>
							<h3>Cloud Management</h3>
							<p>Integer volutpat ante et accumsan commophasellus sed aliquam feugiat lorem aliquet ut enim rutrum phasellus iaculis accumsan dolore magna aliquam veroeros.</p>
							<ul class="actions">
								<li><a href="generic.php" class="button alt">Learn More</a></li>
							</ul>
						</section>
					</div>
				</div>

			</section>
			
		<!-- CTA -->
			<section id="cta">
				
				<h2>Subscribe to our Newsletter</h2>
				<p>To get notified about latest post,please subscribe to our newsletter.</p>
				
				<form>
					<div class="row uniform 50%">
						<div class="8u 12u(3)">
							<input type="email" name="email" id="email" placeholder="Email Address" />
						</div>
						<div class="4u 12u(3)">
							<input type="submit" value="Subscribe" class="fit" />
						</div>
					</div>
				</form>
				
			</section>
			
		<!-- Footer -->
			<footer id="footer">
				<ul class="icons">
					<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
					<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
					<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
					<li><a href="#" class="icon fa-github"><span class="label">Github</span></a></li>
					<li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
					<li><a href="#" class="icon fa-google-plus"><span class="label">Google+</span></a></li>
				</ul>
				<ul class="copyright">
					<li>&copy; Veronica. All rights reserved.</li>
				</ul>
			</footer>

	</body>
</html>
<?php
	session_start();
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Contact Us</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/jquery.scrollgress.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-wide.css" />
		</noscript>
	</head>
	<body>

		<!-- Header -->
			<header id="header" class="skel-layers-fixed">
				<h1><a href="index.php">Veronica</a> by KR</h1>
				<nav id="nav">
					<ul>
						<li><a href="index.php">Home</a></li>
						<li>
							<a href="" class="icon fa-angle-down">Explore</a>
							<ul>
								<li><a href="generic.php">Overview</a></li>
								<li><a href="contact.php">Contact</a></li>
							</ul>
						</li>
						<?php if(array_key_exists('Name',$_SESSION) && !empty($_SESSION['Name'])){
						        echo "<li><a href='logout.php' class='button'>Sign Out</a></li>";
						    }else{
						    	echo "<li><a href='../signin/index.php' class='button'>Sign In</a></li>";
						    }?>
					</ul>
				</nav>
			</header>

		<!-- Main -->
			<section id="main" class="container 75%">
				<header>
					<h2>Contact Us</h2>
					<p>If you have ane query, feel free to ask anything.</p>
				</header>
				<div class="box">
					<form method="post" action="#">
						<div class="row uniform 50%">
							<div class="6u 12u(3)">
								<input type="text" name="name" id="name" value="" placeholder="Name" />
							</div>
							<div class="6u 12u(3)">
								<input type="email" name="email" id="email" value="" placeholder="Email" />
							</div>
						</div>
						<div class="row uniform 50%">
							<div class="12u">
								<input type="text" name="subject" id="subject" value="" placeholder="Subject" />
							</div>
						</div>
						<div class="row uniform 50%">
										<div class="4u 12u(2)">
											<input type="radio" id="priority-low" name="priority" checked>
											<label for="priority-low">Low Priority</label>
										</div>
										<div class="4u 12u(2)">
											<input type="radio" id="priority-normal" name="priority">
											<label for="priority-normal">Normal Priority</label>
										</div>
										<div class="4u 12u(2)">
											<input type="radio" id="priority-high" name="priority">
											<label for="priority-high">High Priority</label>
										</div>
									</div>
									<div class="row uniform 50%">
										<div class="6u 12u(2)">
											<input type="checkbox" id="copy" name="copy">
											<label for="copy">Email me a copy of this message</label>
										</div>
										<div class="6u 12u(2)">
											<input type="checkbox" id="human" name="human" checked>
											<label for="human">I am a human and not a robot</label>
										</div>
									</div>
						<div class="row uniform 50%">
							<div class="12u">
								<textarea name="message" id="message" placeholder="Enter your message" rows="6"></textarea>
							</div>
						</div>
						<div class="row uniform">
							<div class="12u">
								<ul class="actions align-center">
									<li><input type="submit" value="Send Message" /></li>
									<li><input type="reset" value="Reset" class="alt" /></li>
								</ul>
							</div>
						</div>
					</form>
				</div>
			</section>
			
		<!-- Footer -->
			<footer id="footer">
				<ul class="icons">
					<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
					<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
					<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
					<li><a href="#" class="icon fa-github"><span class="label">Github</span></a></li>
					<li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
					<li><a href="#" class="icon fa-google-plus"><span class="label">Google+</span></a></li>
				</ul>
				<ul class="copyright">
					<li>&copy; Veronica. All rights reserved.</li>
				</ul>
			</footer>

	</body>
</html>